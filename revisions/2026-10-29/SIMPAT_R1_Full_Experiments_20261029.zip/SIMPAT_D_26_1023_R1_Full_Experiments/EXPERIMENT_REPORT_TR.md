# SIMPAT-D-26-1023 — R1 tam deney çalıştırma raporu

**İşlem tarihi:** 29 Ekim 2026  
**Esas alınan sürüm:** Yazarın resmî `SIMPAT-D-26-1023 (1).pdf` başvurusu, Drive'daki `SMPAT_FANET_UAV_Contributions_fix.tex`, Aşama 1'de ayrılan R1 Python kodları.  
**Önemli:** Bu paket bir **araştırma çıktısıdır**, hakemlere gönderime hazır revize makale değildir. Sonuçlar kullanımdan önce yöntem ve fiziksel model sınırları açısından değerlendirilmeli.

## 1. Çalıştırılan mevcut yayın deneyleri

| Aile | Tekil senaryo çalıştırması | Durum | Dosyalar |
|---|---:|---|---|
| Temel FANET simülasyonu | 5 temel senaryo | Başarılı | `raw/baseline_results.csv` |
| Yönlendirme: 3 UAV sayısı × 4 protokol × 30 tekrar | 360 | Başarılı | `raw/routing_raw.csv`, `summary/routing_summary.csv` |
| İstatistik: 20 faktör-seviye × 30 tekrar | 600 | Başarılı | `raw/statistical_raw.csv`, `summary/statistical_summary.csv` |
| Kablosuz: 3 UAV sayısı × 2 kanal × 30 tekrar | 180 | Başarılı | `raw/wireless_raw.csv`, `summary/wireless_summary.csv` |
| Birleşik: 4 senaryo × 30 tekrar | 120 | Başarılı | `raw/unified_raw.csv`, `summary/unified_summary.csv` |

**Özgün Drive özetleriyle karşılaştırma:** 42/42 senaryo ortalama PDR değeri karakter/sayısal eşdeğerlik düzeyinde uyuşuyor (en büyük mutlak fark 0). `extra/publication_audit.json` detayları içerir. Bunlar bütün metriklerin eşitliği veya fiziksel geçerlilik kanıtı **değildir**. R1 düzeltmeleri tanımsız SINR/enerji değerlerini NaN olarak ayırmıştır; eski şekiller yine de güncellenmelidir.

R1 önceki 11 birim testinin tamamı başarılı: `logs/unit_tests.log`. Komut ve çalışma süreleri `run_all.sh` ile `logs/experiment_status.log` içindedir.

## 2. Ek hakem deneyleri

### R2.1 — Bağımsız analitik karşılaştırma (turuncu)
- Rastgele iki düğümün 100 × 100 m karede doğrudan bağlanma olasılığı için kapalı-form 2B analitik referans: **0,278015**.
- 50.000 bağımsız iki-düğüm örneğinde Python binary-range simülasyonu: **0,277120**; %95 binom güven aralığı **[0,273200, 0,281066]**. Teorik değer bu aralığın içinde.
- Girişimsiz deterministik kanal denklem kontrolü (serbest-uzay/path-loss, SINR, başarı olasılığı, iletim ve yayılım gecikmesi): bağımsız hesaplarla kod değeri eşleşti.
- 20.000 denemeli tek-hop: beklenen **0,877039**, gözlenen **0,876850**.
- 20.000 denemeli iki-hop: beklenen **0,663184**, gözlenen **0,662250**.
- Dosyalar: `extra/analytical_topology.*`, `extra/analytical_validation.*`.

**Sınırlama:** Bu, matematiksel ve hesaplamalı doğrulamadır; 3B fiziksel UAV sahası, gerçek radyo, ns-3, OMNeT++ veya gerçek MAC sistemiyle dış doğrulama değildir. Hakemin analitik referans seçeneğine destek sağlar; tek başına bütün model geçerliliğini kanıtlamaz.

### R2.4 — Aynı hareket ve trafik üzerinden kanal-kalibrasyon duyarlılığı (turuncu; şekil okunaklılığı R1.4'ü de karşılıyorsa mor)
- 10/20/30 UAV × 5 bağlantı seçimi × 30 tekrarlı senaryo = **450 koşul-çalıştırma**. Aynı seed için İHA hareketleri, paket kaynak-hedef çiftleri ve jitter aynıdır; kablosuz kanal örnekleri paylaşılır.
- Karşılaştırmalar: `binary_35m`, `wireless_unrestricted`, `wireless_35m_cap` (35 m üstü reddedilir, güvenilirlik eşiği korunur), `wireless_same_binary_candidates` (aynı aday bağlantılar, başarı olasılığı örneklenir), `wireless_edge_count_matched` (güvenilir adayların elverdiği ölçüde bağlantı sayısı eşleştirilir, aynı linkler zorunlu değil).
- **20 UAV PDR:** binary **0,88356**; unrestricted wireless **0,90733**; capped wireless **0,37689**; identical candidates wireless **0,16667**; equal link count wireless **0,98222**.
- 20 UAV için ortalama bağlantı sayısı: binary **45,65**; unrestricted **68,26**; reliability-threshold + range-cap **22,09**; identical candidates **45,65**; matched-count **45,50**.
- Yeni sonuçlar gösteriyor ki yöntem seçimi, modelin PDR yorumunu temelden değiştiriyor; **modelin daha yüksek PDR üretmesi, fiziksel olarak daha iyi olduğu anlamına gelmez.**
- Çıktılar: `extra/calibration_raw.csv`, `extra/calibration_summary.csv`, `figures/fig_R2_4_calibration_pdr.{png,svg}`.

**Sınırlama:** Bağlantı sayısını eşitlemek bağlantı konumunu, SINR veya PHY ayrıntılarını eşitlemez. Aynı aday bağlantıları tutmak da güvenilirlik/PHY kalibrasyonunu kanıtlamaz. Bu karşılaştırmalar **kalibrasyona duyarlılık analizleridir**, saha verisiyle ayarlanmış fiziksel model değildir.

### R1.8 — Büyük alan ölçek duyarlılığı (mavi)
- 20/40 UAV × 120/250/500 m yatay alan × sabit 35 m veya yatay uzunlukla orantılı menzil × 30 tekrar = **360 koşul-çalıştırma**.
- 20 UAV, sabit 35 m menzil: 120 m alanda **PDR 0,89467**, 250 m alanda **0,04667**, 500 m alanda **0,00511**.
- 20 UAV, menzil yatay alanla orantılı ölçeklendiğinde: **0,89467**, **0,78978**, **0,66756**.
- Veri: `extra/area_scaling_raw.csv`, `extra/area_scaling_summary.csv`, `figures/fig_R1_8_area_scaling_pdr.{png,svg}`.
- Bu sonuçlar gerçek büyük sahada doğrulama değil, **sentetik topoloji ölçek duyarlılığıdır**. Farklı alanlar 3B hacmi ve UAV yoğunluğunu değiştirir; aynı yoğunlukla genişletilmiş saha deneyi yapılmadı.

### R2.2 — Routing parametre duyarlılığı (turuncu)
- AODV-like TTL: **2, 4, 8, 16 s**; OLSR-like tablo güncellemesi: **1, 2, 5 s**. 20 UAV, 120 saniye, her koşulda 30 tekrar.
- AODV-benzeri TTL 2 s → 16 s: ortalama kontrol mesajı/saniye **104,36 → 98,62**; PDR bu deneyde yaklaşık **0,54161** olarak aynı kaldı.
- OLSR-benzeri güncelleme 1 s → 5 s: PDR **0,54161 → 0,41306**; kontrol mesajı/saniye **80,10 → 16,03**.
- Veri: `extra/routing_timestep_raw.csv`, `extra/routing_timestep_summary.csv`, `figures/fig_R2_2_olsr_pdr.{png,svg}`.

### R2.3 — Hareket/topoloji adımı duyarlılığı (turuncu)
- **0,25 / 0,5 / 1 / 2 s**, trafik yoğunluğu sabit **4 paket/s**, 20 UAV, 120 s, 30 tekrar.
- PDR sırasıyla **0,54958 / 0,54722 / 0,54583 / 0,54014**.
- Veri: `extra/routing_timestep_summary.csv`, `figures/fig_R2_3_timestep_pdr.{png,svg}`.
- **Önemli:** Kod halen adım-tabanlıdır; milisaniye düzeyinde gerçek ayrık-olay transmisyon takvimi, gerçek çarpışma/kuyruk süreci uygulanmadı. Hassasiyet çalışması bu eksikliği tek başına çözmez.

### R2.6 — Revize metrikler ve güven aralıkları (turuncu)
- R1 çıktıları rota başarısızlığıyla paket kaybını, başlangıç topolojisiyle sonradan oluşan değişimi, bağlantı bölüm ömrüyle toplam link etkinliğini ayrıştırır.
- Binary modelin yapay `SINR=99dB`, `Energy=0mJ` placeholder'ları yeni R1 sonuçlarında `N/A` olarak işaretlenmiştir.
- R1'in mevcut `*_ci95` sütunları normal 1,96 yaklaşımıyla **yarı genişlik**tir.
- Bu paket `extra/student_t_ci95_recomputed.csv` ile 42 grup için *Student-t* %95 güven aralığı **yarı genişliğini ayrı hesaplar**; özgün makale tablolarının CI değerlerini sessizce değiştirmez.

## 3. Şu anda bu ortamda çalıştırılamayan talepler

1. **Gerçek AirSim logger izi (R2.5):** `airsim` Python modülü ve AirSim/Unreal runtime bulunmuyor. Mevcut `source=airsim-compatible-sample` CSV üzerinde 30 tekrar yürütüldü; gerçek AirSim kaydı olarak gösterilmeyecek. Kullanıcının çalışan AirSim bilgisayarında veri toplanması gerekiyor.
2. **ns-3 / OMNeT++ birebir fiziksel ağ karşılaştırması (R2.1):** Komutlar ve runtime bu ortamda yok. Analitik/geometrik doğrulamalar yapıldı; bağımsız paket-seviyesi PHY/MAC karşılaştırması bekliyor.
3. **ms düzeyinde ayrık olay zamanlayıcısı:** Uygulanmadı; mevcut gecikme terimleri *modele dayalı*.
4. **Gerçek ölçümle fiziksel kanal parametre kalibrasyonu:** Yapılmadı; sahadan veri veya referans fiziksel model gerekiyor.
5. **Makalenin nihai renkli ve temiz PDF sürümleri:** Sayılar yorumlanıp yöntem karara bağlanmadan yazılmamalı; bu pakette oluşturulmadı.

## 4. Renkli revizyon için kodlama

- **Hakem 1:** mavi `#175CD3` — R1.8 yeni alan çalışması.
- **Hakem 2:** turuncu `#B45309` — R2.1, R2.2, R2.3, R2.4, R2.6 yeni deney ve açıklamaları.
- **Her iki hakem:** mor `#6D28D9` — örn. şekil okunaklılığı (R1.4) ile kanal karşılaştırmasının bilimsel düzeltmesini (R2.4) **aynı yeni şekil açıklaması** karşılıyorsa.
- Grafikteki bilimsel serilerin renkleri bu hakem takip renkleri olarak yorumlanmamalı.

## 5. Sonraki bilimsel karar

Özellikle R2.4 deneyleri, makaledeki önceki Tablo 7 yorumunun kontrolsüz biçimde taşınamayacağını gösterdi. Hangi karşılaştırmanın birincil makale tablosunda kullanılacağı belirlenmeli ve karşılaştırmanın neyi test ettiği açıkça yazılmalı; mevcut gösterimlerin hepsi birlikte verildiğinde fiziksel üstünlük iddiasında bulunulmamalı. Harici AirSim ve ns-3 deneyleri ayrı yürütülmeli. Sonrasında güncel grafikler, metrik tabloları ve renkli LaTeX değişiklikleri işlenip madde madde hakem yanıtı hazırlanmalı.
